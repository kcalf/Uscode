# backend/create_admin.py
import asyncio
from getpass import getpass
from sqlalchemy.orm import Session

# 프로젝트의 모듈을 가져오기 위한 설정
# 이 스크립트는 프로젝트 루트에서 python -m backend.create_admin 으로 실행될 수 있습니다.
from app.database import SessionLocal
from app.schemas import UserCreate, UserRole
from app.crud import create_user, get_user_by_username

async def main():
    """
    CLI를 통해 관리자 계정을 생성하는 스크립트.
    """
    print("--- 관리자 계정 생성 ---")
    db: Session = SessionLocal()
    try:
        # 사용자로부터 정보 입력받기
        username = input("관리자 사용자 이름을 입력하세요: ").strip()
        if not username:
            print("사용자 이름은 비워둘 수 없습니다.")
            return

        # 이미 존재하는 사용자인지 확인
        if get_user_by_username(db, username):
            print(f"오류: 사용자 '{username}'은(는) 이미 존재합니다.")
            return

        email = input("관리자 이메일을 입력하세요 (선택사항): ").strip()
        password = getpass("관리자 비밀번호를 입력하세요: ")
        password_confirm = getpass("비밀번호를 다시 입력하세요: ")

        if password != password_confirm:
            print("오류: 비밀번호가 일치하지 않습니다.")
            return

        # 관리자 역할로 UserCreate 스키마 생성
        admin_user_in = UserCreate(
            username=username,
            email=email or None,
            password=password,
            role=UserRole.ADMIN  # 역할을 ADMIN으로 명시
        )

        # CRUD 함수를 사용하여 관리자 생성
        new_admin = create_user(db=db, user=admin_user_in)
        print(f"성공: 관리자 계정 '{new_admin.username}'이(가) 생성되었습니다.")

    finally:
        db.close()

if __name__ == "__main__":
    asyncio.run(main())

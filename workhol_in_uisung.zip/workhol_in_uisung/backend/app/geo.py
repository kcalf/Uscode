import requests
from geopy.distance import geodesic
from urllib.parse import urlencode

# Google Geocoding API 설정
GEOCODING_API_KEY = "AIzaSyD8P2HFa_PxEknt3mXTWFc7gTTYm-nmLmE"
GEOCODING_BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json"

def get_coordinates(address):
    """주소를 위도/경도로 변환"""
    params = {"address": address, "key": GEOCODING_API_KEY}
    response = requests.get(GEOCODING_BASE_URL, params=params)
    results = response.json()
    
    # 디버깅 정보 출력
    print(f"[DEBUG] Address: {address}")
    print(f"[DEBUG] Response: {results}")
    
    if results['status'] == 'OK':
        location = results['results'][0]['geometry']['location']
        print(f"[DEBUG] Coordinates: ({location['lat']}, {location['lng']})")
        return (location['lat'], location['lng'])
    else:
        raise ValueError(f"Geocoding 실패: {results['status']}")

def calculate_distance(coord1, coord2):
    """두 좌표 간 거리 계산 (단위: km)"""
    return geodesic(coord1, coord2).kilometers

# 메인 실행
if __name__ == "__main__":
    address1 = input("첫 번째 주소 입력: ")
    address2 = input("두 번째 주소 입력: ")
    
    try:
        coord1 = get_coordinates(address1)
        coord2 = get_coordinates(address2)
        
        distance = calculate_distance(coord1, coord2)
        
        print(f"\n계산 결과:")
        print(f"- 주소 1: {address1} → 좌표: {coord1}")
        print(f"- 주소 2: {address2} → 좌표: {coord2}")
        print(f"- 두 지점 간 거리: {distance:.2f} km")
    
    except Exception as e:
        print(f"오류 발생: {str(e)}")
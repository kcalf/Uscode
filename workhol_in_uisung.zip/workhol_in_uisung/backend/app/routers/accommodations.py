from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies

router = APIRouter()

@router.get("/available", response_model=list[schemas.Accommodation])
def get_available_accommodations(start_date: str, end_date: str, required_capacity: int, db: Session = Depends(dependencies.get_db)):
    accommodations = crud.get_available_accommodations(db, start_date, end_date, required_capacity)
    return accommodations

@router.post("/assign")
def assign_accommodation(accommodation_id: int, applicant_id: int, db: Session = Depends(dependencies.get_db)):
    accommodation = crud.assign_accommodation(db, accommodation_id, applicant_id)
    if not accommodation:
        raise HTTPException(status_code=404, detail="Accommodation not found")
    return {"message": "Accommodation assigned successfully"}

from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies, models

router = APIRouter()

@router.get("/", response_model=list[schemas.Job])
def read_jobs(response: Response, skip: int = 0, limit: int = 10, db: Session = Depends(dependencies.get_db)):
    # 일반 사용자도 볼 수 있으므로 인증/권한 요구 안 함 (또는 선택적 인증)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

    return crud.get_jobs(db, skip=skip, limit=limit)

@router.post("/", response_model=schemas.Job)
def create_job_request(job: schemas.JobCreate,
                        current_user: models.User = Depends(dependencies.get_resident_user),
                        db: Session = Depends(dependencies.get_db)):
    
    resident_profile = crud.get_resident_by_user_id(db, current_user.id)
    if not resident_profile:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="주민 프로필이 등록되지 않았습니다."
        )

    new_job = crud.create_job(db, job, resident_id=resident_profile.id)

    crud.create_job_approval_request(
        db=db,
        job_id=new_job.id,
        resident_id=resident_profile.id
    )

    return new_job

@router.get("/resident/me", response_model=list[schemas.Job])
def get_my_jobs(current_user: models.User = Depends(dependencies.get_resident_user), # 주민 권한 필요
                db: Session = Depends(dependencies.get_db)):
    resident_profile = crud.get_resident_by_user_id(db, current_user.id)
    if not resident_profile:
        raise HTTPException(status_code=404, detail="Resident profile not found.")
    return crud.get_jobs_by_resident(db, resident_profile.id)
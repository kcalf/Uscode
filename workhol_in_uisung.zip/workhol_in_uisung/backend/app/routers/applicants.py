from fastapi import APIRouter, Depends, HTTPException, FastAPI
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies, models

router = APIRouter()

@router.get("/job/{job_id}", response_model=list[schemas.Applicant])
def get_applicants_by_job(job_id: int,
                        current_user: models.User = Depends(dependencies.get_resident_user), # 주민 권한 필요
                        db: Session = Depends(dependencies.get_db)):
    # 해당 알바를 등록한 주민만 지원자 목록을 볼 수 있도록 추가 로직 필요
    job = db.query(models.JobList).filter(models.JobList.id == job_id).first()
    if not job or job.resident.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You are not authorized to view applicants for this job.")
    return crud.get_applicants_by_job(db, job_id)

@router.post("/{applicant_id}/approve")
def approve_applicant(applicant_id: int,
                    current_user: models.User = Depends(dependencies.get_resident_user), # 주민 권한 필요
                    db: Session = Depends(dependencies.get_db)):
    # ... (승인 로직)
    applicant = crud.update_applicant_approval(db, applicant_id, True)
    if not applicant:
        raise HTTPException(status_code=404, detail="Applicant not found")
    # 해당 지원자의 알바가 현재 주민의 것인지 확인하는 로직 추가
    if applicant.job.resident.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You are not authorized to approve this applicant.")

    notification_message = f"'{applicant.job.title}' 알바에 승인되었습니다. 배정된 숙소를 확인하세요."
    crud.create_notification(db, schemas.NotificationCreate(
        applicant_id=applicant.id, 
        message=notification_message,
        user_id=applicant.user_id 
    ))
    # TODO: Trigger accommodation assignment here

@router.post("/{applicant_id}/reject")
def reject_applicant(applicant_id: int, db: Session = Depends(dependencies.get_db)):
    applicant = crud.update_applicant_approval(db, applicant_id, False)
    if not applicant:
        raise HTTPException(status_code=404, detail="Applicant not found")
    
    notification_message = f"'{applicant.job.title}' 알바 지원이 거절되었습니다."
    crud.create_notification(db, schemas.NotificationCreate(
        applicant_id=applicant.id,
        message=notification_message
    ))

    # TODO: Send rejection notification
    return applicant

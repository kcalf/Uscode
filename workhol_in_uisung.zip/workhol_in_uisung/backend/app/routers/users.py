from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies

router = APIRouter()

@router.get("/", response_model=list[schemas.Job])
def read_jobs(skip: int = 0, limit: int = 10, db: Session = Depends(dependencies.get_db)):
    jobs = crud.get_jobs(db, skip=skip, limit=limit)
    return jobs

@router.post("/apply", response_model=schemas.Applicant)
def apply_job(applicant: schemas.ApplicantCreate, db: Session = Depends(dependencies.get_db)):
    return crud.create_applicant(db, applicant)

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from .. import crud, schemas, dependencies, models

router = APIRouter()

@router.post("/", response_model=schemas.Resident)
def create_resident_profile(resident: schemas.ResidentCreate,
                            current_user: models.User = Depends(dependencies.get_resident_user), # 주민 권한 필요
                            db: Session = Depends(dependencies.get_db)):
    # 이미 프로필이 있다면 중복 생성 방지
    if crud.get_resident_by_user_id(db, current_user.id):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Resident profile already exists for this user.")
    return crud.create_resident(db, resident, user_id=current_user.id)

@router.get("/me", response_model=schemas.Resident)
def get_my_resident_profile(current_user: models.User = Depends(dependencies.get_resident_user), # 주민 권한 필요
                            db: Session = Depends(dependencies.get_db)):
    resident = crud.get_resident_by_user_id(db, current_user.id)
    if not resident:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resident profile not found.")
    return resident

@router.post("/register", status_code=status.HTTP_201_CREATED, response_model=schemas.User)
def register_user(user_req: schemas.UserRegisterRequest, db: Session = Depends(dependencies.get_db)):
    # 중복 사용자명 체크
    existing_user = crud.get_user_by_username(db, user_req.username)
    if existing_user:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")

    # 중복 이메일 체크
    existing_email = db.query(models.User).filter(models.User.email == user_req.email).first()
    if existing_email:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already registered")

    try:
        # 비밀번호 확인은 Pydantic validator에서 처리됨
        user_create = schemas.UserCreate(
            username=user_req.username,
            email=user_req.email,
            password=user_req.password1,
            role=schemas.UserRole.USER  # 기본 역할 지정
        )
        new_user = crud.create_user(db, user_create)
        return new_user
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Failed to create user due to DB error")
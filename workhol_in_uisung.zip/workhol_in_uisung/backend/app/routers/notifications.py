from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies

router = APIRouter()

@router.get("/user/{user_id}", response_model=list[schemas.Notification])
def get_user_notifications(user_id: int, db: Session = Depends(dependencies.get_db)):
    notifications = crud.get_notifications_for_user(db, user_id)
    return notifications

@router.get("/resident/{resident_id}", response_model=list[schemas.Notification])
def get_resident_notifications(resident_id: int, db: Session = Depends(dependencies.get_db)):
    notifications = crud.get_notifications_for_resident(db, resident_id)
    return notifications

@router.get("/applicant/{applicant_id}", response_model=list[schemas.Notification])
def get_applicant_notifications(applicant_id: int, db: Session = Depends(dependencies.get_db)):
    notifications = crud.get_notifications_for_applicant(db, applicant_id)
    return notifications

@router.post("/{notification_id}/read", response_model=schemas.Notification)
def mark_as_read(notification_id: int, db: Session = Depends(dependencies.get_db)):
    notification = crud.mark_notification_as_read(db, notification_id)
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    return notification

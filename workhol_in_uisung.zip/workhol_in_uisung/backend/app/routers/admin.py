from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from .. import crud, schemas, dependencies, models

router = APIRouter()

@router.get("/approval_requests", response_model=list[schemas.JobApprovalRequest])
def get_approval_requests(db: Session = Depends(dependencies.get_db),
                        current_user: models.User = Depends(dependencies.get_admin_user)): # 관리자 권한 필요
    return crud.get_pending_approval_requests(db)

@router.post("/approval_requests/{request_id}/approve", status_code=status.HTTP_204_NO_CONTENT)
def approve_request(request_id: int, db: Session = Depends(dependencies.get_db),
                    current_user: models.User = Depends(dependencies.get_admin_user)):
    # 이 함수 호출이 정상적으로 이루어지는지 확인
    approved_job, resident_id = crud.approve_job_request(db, request_id)
    if not approved_job:
        raise HTTPException(status_code=404, detail="Request not found")
    
    # 알림 생성 로직
    notification_message = f"알바 등록 요청 '{approved_job.title}'이(가) 승인되었습니다."
    crud.create_notification(db, schemas.NotificationCreate(resident_id=resident_id, message=notification_message))

@router.post("/approval_requests/{request_id}/reject")
def reject_request(request_id: int, db: Session = Depends(dependencies.get_db)):
    updated_request = crud.update_approval_request_status(db, request_id, "rejected")
    if not updated_request:
        raise HTTPException(status_code=404, detail="Request not found")

    # 알림 발송: 주민에게 알바가 거절되었음을 알림
    resident_id_for_notification = updated_request.resident_id
    notification_message = f"알바 등록 요청 '{updated_request.job.title}'이(가) 거절되었습니다."
    crud.create_notification(db, schemas.NotificationCreate(
        resident_id=resident_id_for_notification,
        message=notification_message
    ))

    return updated_request

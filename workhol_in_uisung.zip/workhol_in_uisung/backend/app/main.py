from fastapi import FastAPI
from .routers import users, residents, admin, jobs, accommodations, applicants, notifications, auth
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="워홀 in 의성")

origins = [
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:8080" 
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # 허용할 Origin 목록
    allow_credentials=True, # 자격 증명(쿠키, HTTP 인증 등) 허용 여부
    allow_methods=["*"],    # 모든 HTTP 메서드 (GET, POST, PUT, DELETE 등) 허용
    allow_headers=["*"],    # 모든 HTTP 헤더 허용
)

app.include_router(users.router, prefix="/users", tags=["users"])
app.include_router(residents.router, prefix="/residents", tags=["residents"])
app.include_router(admin.router, prefix="/admin", tags=["admin"])

app.include_router(jobs.router, prefix="/jobs", tags=["jobs"])
app.include_router(accommodations.router, prefix="/accommodations", tags=["accommodations"])
app.include_router(applicants.router, prefix="/applicants", tags=["applicants"])

app.include_router(notifications.router, prefix="/notifications", tags=["notifications"])
app.include_router(auth.router, tags=["Authentication"])

@app.get("/")
async def root():
    return {"message": "워홀 in 의성 API 서버가 정상 작동 중입니다."}

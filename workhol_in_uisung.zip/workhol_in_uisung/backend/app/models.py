from sqlalchemy import Column, Integer, String, Date, ForeignKey, Boolean, DateTime
from sqlalchemy import Enum as SqlEnum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base
from enum import Enum as pyEnum

class UserRole(str, pyEnum):
    user = "user"          # 일반 사용자 (단기 알바 지원 가능)
    resident = "resident"  # 의성군 주민 (알바 등록 및 지원자 관리 가능)
    admin = "admin"        # 관리자 (모든 관리 기능 접근 가능)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    email = Column(String, unique=True, index=True, nullable=True) # 선택 사항
    role = Column(SqlEnum(UserRole, name="userrole"), nullable=False)
    is_active = Column(Boolean, default=True)

    notifications = relationship("Notification", back_populates="user")
    resident_profile = relationship("Resident", back_populates="user", uselist=False)

class JobList(Base):
    __tablename__ = "job_list"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    location = Column(String)
    hourly_wage = Column(Integer)
    start_date = Column(Date)
    end_date = Column(Date)
    number_of_workers = Column(Integer)
    resident_id = Column(Integer, ForeignKey("residents.id"))
    approved = Column(Boolean, default=False)

    resident = relationship("Resident", back_populates="jobs")
    applicants = relationship("Applicant", back_populates="job")
    approval_request = relationship("JobApprovalRequest", back_populates="job", uselist=False)

class JobApprovalRequest(Base):
    __tablename__ = "job_approval_requests"
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("job_list.id"))
    resident_id = Column(Integer, ForeignKey("residents.id"))
    status = Column(String, default="pending")  # pending, approved, rejected

    job = relationship("JobList", back_populates="approval_request")

class Applicant(Base):
    __tablename__ = "applicants"
    id = Column(Integer, primary_key=True, index=True)
    user_name = Column(String)
    birth_date = Column(Date)
    contact = Column(String)
    other_info = Column(String, nullable=True)
    job_id = Column(Integer, ForeignKey("job_list.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    approved = Column(Boolean, default=False)

    job = relationship("JobList", back_populates="applicants")
    accommodation = relationship("Accommodation", back_populates="applicant", uselist=False)

class Resident(Base):
    __tablename__ = "residents"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    name = Column(String)
    photo_url = Column(String)
    contact = Column(String)
    job_description = Column(String)
    hourly_wage = Column(Integer)
    job_location = Column(String)
    job_start_date = Column(Date)
    job_end_date = Column(Date)
    other_info = Column(String, nullable=True)

    user = relationship("User", back_populates="resident_profile")
    jobs = relationship("JobList", back_populates="resident")

class Accommodation(Base):
    __tablename__ = "accommodations"
    id = Column(Integer, primary_key=True, index=True)
    address = Column(String)
    capacity = Column(Integer)
    available_start_date = Column(Date)
    available_end_date = Column(Date)
    assigned_to_applicant_id = Column(Integer, ForeignKey("applicants.id"), nullable=True)

    applicant = relationship("Applicant", back_populates="accommodation")

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    resident_id = Column(Integer, nullable=True) # 알림을 받을 주민의 ID
    applicant_id = Column(Integer, nullable=True) # 알림을 받을 지원자의 ID (specific to applicant, e.g., accommodation assigned)
    message = Column(String, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="notifications")
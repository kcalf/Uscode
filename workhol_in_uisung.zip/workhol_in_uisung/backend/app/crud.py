from sqlalchemy.orm import Session, joinedload
from . import models, schemas, dependencies
from datetime import date

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_user_by_id(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

from fastapi import HTTPException, status

def create_user(db: Session, user: schemas.UserCreate):
    # 이메일 중복 검사
    existing_user = db.query(models.User).filter(models.User.email == user.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="이미 등록된 이메일입니다."
        )

    # 사용자 생성
    hashed_password = dependencies.get_password_hash(user.password)
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_password,
        role=user.role.value
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    # 주민(role)일 경우 Resident 프로필 생성
    if user.role == schemas.UserRole.RESIDENT:
        db_resident = models.Resident(
            user_id=db_user.id,
            name=db_user.username,
            photo_url="",
            contact="",
            job_description="",
            hourly_wage=0,
            job_location="",
            job_start_date=date.today(),
            job_end_date=date.today()
        )
        db.add(db_resident)
        db.commit()
        db.refresh(db_resident)
        db_user.resident_profile = db_resident
        db.commit()
        db.refresh(db_user)

    return db_user

# Job CRUD

def update_applicant_approval(db: Session, applicant_id: int, approved: bool):
    applicant = db.query(models.Applicant).filter(models.Applicant.id == applicant_id).first()
    if not applicant:
        return None

    applicant.approved = approved

    # 지원자를 '승인'한 경우, 해당 알바를 '모집 마감' 상태로 변경
    if approved:
        job = db.query(models.JobList).filter(models.JobList.id == applicant.job_id).first()
        if job:
            job.approved = False  # 모집 중인 리스트에서 제외

    db.commit()
    db.refresh(applicant)
    return applicant

def get_jobs(db: Session, skip: int = 0, limit: int = 100):

    db.expire_all()

    return db.query(models.JobList).filter(models.JobList.approved == True).offset(skip).limit(limit).all()

def get_jobs_by_resident(db: Session, resident_id: int):
    return db.query(models.JobList).options(
        joinedload(models.JobList.applicants)
    ).filter(models.JobList.resident_id == resident_id).order_by(models.JobList.id.desc()).all()

def create_job(db: Session, job: schemas.JobCreate, resident_id: int):
    db_job = models.JobList(**job.dict(), resident_id=resident_id, approved=False)
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job

# Applicant CRUD

def create_applicant(db: Session, applicant: schemas.ApplicantCreate):
    db_applicant = models.Applicant(**applicant.dict(), approved=False)
    db.add(db_applicant)
    db.commit()
    db.refresh(db_applicant)
    return db_applicant

def get_applicants_by_job(db: Session, job_id: int):
    return db.query(models.Applicant).filter(models.Applicant.job_id == job_id).all()

# Resident CRUD

def get_resident(db: Session, resident_id: int):
    return db.query(models.Resident).filter(models.Resident.id == resident_id).first()

def create_resident(db: Session, resident: schemas.ResidentCreate, user_id: int):
    db_resident = models.Resident(**resident.dict(), user_id=user_id)
    db.add(db_resident)
    db.commit()
    db.refresh(db_resident)
    return db_resident

# JobApprovalRequest CRUD

def create_job_approval_request(db: Session, job_id: int, resident_id: int):
    db_request = models.JobApprovalRequest(job_id=job_id, resident_id=resident_id, status="pending")
    db.add(db_request)
    db.commit()
    db.refresh(db_request)
    return db_request

def get_pending_approval_requests(db: Session):
    return db.query(models.JobApprovalRequest).options(
        joinedload(models.JobApprovalRequest.job)
    ).filter(models.JobApprovalRequest.status == "pending").all()

def update_approval_request_status(db: Session, request_id: int, status: str):
    request = db.query(models.JobApprovalRequest).filter(models.JobApprovalRequest.id == request_id).first()
    if request:
        request.status = status
        db.commit()
        db.refresh(request)
    return request

def approve_job_request(db: Session, request_id: int):
    request = db.query(models.JobApprovalRequest).filter(models.JobApprovalRequest.id == request_id).first()
    if not request:
        return None, None
    
    job = db.query(models.JobList).filter(models.JobList.id == request.job_id).first()
    if job:
        job.approved = True  # 이 부분이 핵심
        db.delete(request)
        db.commit()
        db.refresh(job)
        return job, job.resident_id
    return None, None

def get_jobs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.JobList).filter(models.JobList.approved == True).offset(skip).limit(limit).all()

def reject_job_request(db: Session, request_id: int):
    request = db.query(models.JobApprovalRequest).filter(models.JobApprovalRequest.id == request_id).first()
    if not request:
        return None, None
        
    job = db.query(models.JobList).filter(models.JobList.id == request.job_id).first()
    if job:
        job_title = job.title
        resident_id = job.resident_id
        db.delete(job)
        db.delete(request)
        db.commit()
        return job_title, resident_id
    return None, None

# Accommodation CRUD

def get_available_accommodations(db: Session, start_date, end_date, required_capacity):
    return db.query(models.Accommodation).filter(
        models.Accommodation.available_start_date <= start_date,
        models.Accommodation.available_end_date >= end_date,
        models.Accommodation.capacity >= required_capacity,
        models.Accommodation.assigned_to_applicant_id == None
    ).all()

def assign_accommodation(db: Session, accommodation_id: int, applicant_id: int):
    accommodation = db.query(models.Accommodation).filter(models.Accommodation.id == accommodation_id).first()
    if accommodation:
        accommodation.assigned_to_applicant_id = applicant_id
        db.commit()
        db.refresh(accommodation)
    return accommodation

def get_jobs_by_resident(db: Session, resident_id: int):
    return db.query(models.JobList).filter(models.JobList.resident_id == resident_id).all()

def create_notification(db: Session, notification: schemas.NotificationCreate):
    db_notification = models.Notification(**notification.dict())
    db.add(db_notification)
    db.commit()
    db.refresh(db_notification)
    return db_notification

def get_notifications_for_user(db: Session, user_id: int):
    return db.query(models.Notification).filter(models.Notification.user_id == user_id).order_by(models.Notification.created_at.desc()).all()

def get_notifications_for_resident(db: Session, resident_id: int):
    # 주민에게 보내진 알림 조회 (resident_id가 해당 주민인 경우)
    return db.query(models.Notification).filter(models.Notification.resident_id == resident_id).order_by(models.Notification.created_at.desc()).all()

def get_notifications_for_applicant(db: Session, applicant_id: int):
    # 특정 지원자에게 보내진 알림 조회 (applicant_id가 해당 지원자인 경우)
    return db.query(models.Notification).filter(models.Notification.applicant_id == applicant_id).order_by(models.Notification.created_at.desc()).all()

def mark_notification_as_read(db: Session, notification_id: int):
    notification = db.query(models.Notification).filter(models.Notification.id == notification_id).first()
    if notification:
        notification.is_read = True
        db.commit()
        db.refresh(notification)
    return notification

def get_resident_by_user_id(db: Session, user_id: int):
    return db.query(models.Resident).filter(models.Resident.user_id == user_id).first()

def get_resident_by_resident_id(db: Session, resident_id: int):
    return db.query(models.Resident).filter(models.Resident.id == resident_id).first()

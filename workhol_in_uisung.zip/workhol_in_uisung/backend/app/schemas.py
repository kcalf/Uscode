from pydantic import BaseModel, EmailStr, Field
from datetime import date, datetime
from typing import Optional, List
from enum import Enum as PyEnum

class UserRole(str, PyEnum): 
    USER = "user"
    RESIDENT = "resident"
    ADMIN = "admin"

class UserBase(BaseModel):
    username: str
    email: EmailStr = Field(..., description="유효한 이메일 주소를 입력하세요.")

class UserCreate(UserBase):
    password: str
    role: UserRole = UserRole.USER # 회원가입 시 역할 선택

class User(UserBase):
    id: int
    is_active: bool
    role: UserRole

    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    username: str
    password: str

from pydantic import BaseModel, EmailStr, validator

class UserRegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password1: str
    password2: str
    role: Optional[UserRole] = UserRole.USER

    @validator("password2")
    def passwords_match(cls, v, values):
        if "password1" in values and v != values["password1"]:
            raise ValueError("Passwords do not match")
        return v

    def to_user_create(self) -> "UserCreate":
        return UserCreate(
            username=self.username,
            email=self.email,
            password=self.password1,
            role=self.role
        )

class Token(BaseModel):
    access_token: str
    token_type: str
    user: User # 로그인 성공 시 사용자 정보도 함께 반환

class TokenData(BaseModel):
    username: Optional[str] = None
    user_id: Optional[int] = None
    role: Optional[UserRole] = None

class JobBase(BaseModel):
    title: str
    description: str
    location: str
    hourly_wage: int
    start_date: date
    end_date: date
    number_of_workers: int

class JobCreate(JobBase):
    pass

class ApplicantBase(BaseModel):
    user_name: str
    birth_date: date
    contact: str
    other_info: Optional[str] = None
    job_id: int

class Applicant(ApplicantBase):
    id: int
    user_name: str
    birth_date: date
    contact: str
    other_info: Optional[str] = None
    job_id: int
    approved: bool

    class Config:
        from_attributes = True

class Job(BaseModel):
    id: int
    title: str
    description: str
    location: str
    hourly_wage: int
    start_date: date
    end_date: date
    number_of_workers: int
    resident_id: int
    approved: bool
    
    applicants: List[Applicant] = [] 

    class Config:
        from_attributes = True

class JobApprovalRequestBase(BaseModel):
    job_id: int
    resident_id: int

class JobApprovalRequestCreate(JobApprovalRequestBase):
    pass

class JobApprovalRequest(JobApprovalRequestBase):
    id: int
    job_id:int
    resident_id: int
    status: str

    job:Job

    class Config:
        from_attributes = True

class ApplicantCreate(ApplicantBase):
    pass

class ResidentBase(BaseModel):
    name: str
    photo_url: str
    contact: str
    job_description: str
    hourly_wage: int
    job_location: str
    job_start_date: date
    job_end_date: date
    other_info: Optional[str] = None

class ResidentCreate(ResidentBase):
    pass

class Resident(ResidentBase):
    id: int
    user_id: int # User ID 포함
    user: User # User 정보도 함께 반환 (선택 사항)

    class Config:
        orm_mode = True

class AccommodationBase(BaseModel):
    address: str
    capacity: int
    available_start_date: date
    available_end_date: date

class AccommodationCreate(AccommodationBase):
    pass

class Accommodation(AccommodationBase):
    id: int
    assigned_to_applicant_id: Optional[int] = None

    class Config:
        orm_mode = True

class NotificationBase(BaseModel):
    message: str
    user_id: Optional[int] = None 
    resident_id: Optional[int] = None
    applicant_id: Optional[int] = None

class NotificationCreate(NotificationBase):
    pass

class Notification(NotificationBase):
    id: int
    is_read: bool
    created_at: datetime
    user: Optional[User] # User 정보 함께 반환 (선택 사항)

    class Config:
        orm_mode = True
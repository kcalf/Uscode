CREATE TYPE userrole AS ENUM ('user', 'resident', 'admin');

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
    "role" userrole DEFAULT 'user' NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL
);

DROP TABLE IF EXISTS residents CASCADE; -- 기존 테이블이 있다면 삭제 후 재생성 (개발 단계에서만 사용)
CREATE TABLE IF NOT EXISTS residents (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id), -- users 테이블 참조, 1:1 관계를 위해 UNIQUE
    name VARCHAR(100) NOT NULL,
    photo_url TEXT,
    contact VARCHAR(50) NOT NULL,
    job_description TEXT NOT NULL,
    hourly_wage INTEGER NOT NULL,
    job_location VARCHAR(100) NOT NULL,
    job_start_date DATE NOT NULL,
    job_end_date DATE NOT NULL,
    other_info TEXT
);

CREATE TABLE IF NOT EXISTS job_list (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(100) NOT NULL,
    hourly_wage INTEGER NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    number_of_workers INTEGER NOT NULL,
    resident_id INTEGER REFERENCES residents(id),
    approved BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS job_approval_requests (
    id SERIAL PRIMARY KEY,
    job_id INTEGER REFERENCES job_list(id),
    resident_id INTEGER REFERENCES residents(id),
    status VARCHAR(20) DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS applicants (
    id SERIAL PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    contact VARCHAR(50) NOT NULL,
    other_info TEXT,
    job_id INTEGER REFERENCES job_list(id),
    user_id INTEGER REFERENCES users(id),
    approved BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS accommodations (
    id SERIAL PRIMARY KEY,
    address VARCHAR(200) NOT NULL,
    capacity INTEGER NOT NULL,
    available_start_date DATE NOT NULL,
    available_end_date DATE NOT NULL,
    assigned_to_applicant_id INTEGER REFERENCES applicants(id)
);

DROP TABLE IF EXISTS notifications CASCADE; -- 기존 테이블이 있다면 삭제 후 재생성
CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    resident_id INTEGER REFERENCES residents(id),
    applicant_id INTEGER REFERENCES applicants(id),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
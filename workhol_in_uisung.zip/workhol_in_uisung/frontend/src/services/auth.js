// frontend/src/services/auth.js
import axios from 'axios';

const API_BASE_URL = '/api';

const authApi = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const register = async (username, password, role, email) => {
  const response = await authApi.post('/register', { username, password, role, email });
  return response.data;
};

export const login = async (username, password) => {
  const form_data = new FormData();
  form_data.append('username', username);
  form_data.append('password', password);
  // OAuth2PasswordRequestForm은 application/x-www-form-urlencoded 형식의 데이터를 받으므로 FormData 사용
  const response = await authApi.post('/token', form_data, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return response.data;
};

export const getMe = async (token) => {
  const response = await authApi.get('/me/', {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

export default authApi;

import axios from 'axios';

// Gemini 문장 생성 API 호출 함수
export const generateGeminiSentence = async (title, description) => {
  try {
    // 백엔드에 /gemini/generate 엔드포인트가 있다고 가정
    const response = await axios.get('/gemini/generate', {
      params: { title, description },
    });
    console.log(response.data.text);
    return response.data.text; // { text: '생성된 문장' } 형태 반환 가정
  } catch (error) {
    console.error('Gemini 문장 생성 실패:', error);
    return null;
  }
};

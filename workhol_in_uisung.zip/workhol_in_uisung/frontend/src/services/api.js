import axios from 'axios';

// 백엔드 API의 기본 URL을 환경 변수에서 가져오거나 기본값을 사용합니다.
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

// 재사용을 위해 기본 설정이 적용된 Axios 인스턴스를 생성합니다.
const api = axios.create({
  baseURL: API_BASE_URL,
});

// --- 인증 (Auth) API ---
export const register = (userData) => api.post('/register', userData);

export const login = (username, password) => {
  const formData = new FormData();
  formData.append('username', username);
  formData.append('password', password);
  return api.post('/token', formData, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
};

export const getMe = (token) => api.get('/me/', {
  headers: { Authorization: `Bearer ${token}` },
});

// --- 알바 (Job) API - Public ---
// 모집 중인 모든 알바 목록을 가져옵니다.
export const getJobs = () => api.get('/jobs/',{
  headers: {
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Expires': '0',
  },
});

// --- 지원자 (Applicant) API - User ---
// 사용자가 알바에 지원합니다.
export const createApplicant = (applicationData) => api.post('/users/apply', applicationData);

// --- 주민 (Resident) API ---
// 주민이 등록한 알바 목록을 가져옵니다.
export const getResidentJobs = (token) => api.get('/jobs/resident/me', {
  headers: { Authorization: `Bearer ${token}` },
});

// 주민이 가장 최근에 작성한 프로필(알바 정보)을 불러옵니다.
export const getResidentLastProfile = (token) => api.get('/residents/me/last_profile', {
  headers: { Authorization: `Bearer ${token}` },
});

// 주민이 새로운 알바 등록을 요청합니다.
export const createJobRequest = (jobData, token) => api.post('/jobs/', jobData, {
  headers: { Authorization: `Bearer ${token}` },
});

// 주민이 지원자를 승인합니다.
export const approveApplicantByResident = (applicantId, token) => api.post(`/applicants/${applicantId}/approve`, {}, {
  headers: { Authorization: `Bearer ${token}` },
});

// 주민이 지원자를 거절합니다.
export const rejectApplicantByResident = (applicantId, token) => api.post(`/applicants/${applicantId}/reject`, {}, {
  headers: { Authorization: `Bearer ${token}` },
});

// --- 관리자 (Admin) API ---
// 관리자가 승인 대기 중인 알바 요청 목록을 가져옵니다.
export const getAdminApprovalRequests = (token) => api.get('/admin/approval_requests', {
  headers: { Authorization: `Bearer ${token}` },
});

// 관리자가 알바 등록 요청을 승인합니다.
export const approveJobRequestByAdmin = (requestId, token) => api.post(`/admin/approval_requests/${requestId}/approve`, {}, {
  headers: { Authorization: `Bearer ${token}` },
});

// 관리자가 알바 등록 요청을 거절합니다.
export const rejectJobRequestByAdmin = (requestId, token) => api.post(`/admin/approval_requests/${requestId}/reject`, {}, {
  headers: { Authorization: `Bearer ${token}` },
});

// 관리자가 알바를 직접 추가합니다. (백엔드에 해당 API 엔드포인트 구현 필요)
export const createJobDirectlyByAdmin = (jobData, token) => api.post('/admin/jobs/', jobData, {
  headers: { Authorization: `Bearer ${token}` },
});

// --- 알림 (Notification) API ---
// 내 알림 목록을 가져옵니다. (백엔드에 /me 엔드포인트 구현 필요)
export const getMyNotifications = (token) => api.get('/notifications/user/me', {
  headers: { Authorization: `Bearer ${token}` },
});

export const markNotificationAsRead = (notificationId, token) => api.post(`/notifications/${notificationId}/read`, {}, {
  headers: { Authorization: `Bearer ${token}` },
});


export default api;

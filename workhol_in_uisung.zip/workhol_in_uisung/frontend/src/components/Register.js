// frontend/src/components/Register.js
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [role, setRole] = useState('user'); // 기본값은 일반 사용자
    const { signUp } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        await signUp(username, password, role, email);
        alert('회원가입 및 로그인 성공!');
        navigate('/'); // 회원가입 후 홈으로 이동
    } catch (error) {
        alert('회원가입 실패: ' + (error.response?.data?.detail || '알 수 없는 오류'));
    }
    };

    return (
    <div className="auth-form-container">
        <h2>회원가입</h2>
        <form onSubmit={handleSubmit}>
        <label>
            사용자 이름:
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <label>
            비밀번호:
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <label>
            이메일 (선택 사항):
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>
            역할 선택:
            <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="user">일반 사용자 (단기 알바 지원)</option>
            <option value="resident">의성군 주민 (알바 등록 및 관리)</option>
            {/* 관리자 계정은 직접 DB에서 생성하거나, 초기 관리자 등록 API가 필요 */}
            </select>
        </label>
        <button type="submit">회원가입</button>
        </form>
        <p>이미 계정이 있으신가요? <a href="/login">로그인</a></p>
    </div>
    );
}

export default Register;

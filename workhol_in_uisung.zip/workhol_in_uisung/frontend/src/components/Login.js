// frontend/src/components/Login.js
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const { signIn } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        await signIn(username, password);
        alert('로그인 성공!');
        navigate('/'); // 로그인 후 홈으로 이동
    } catch (error) {
        alert('로그인 실패: ' + (error.response?.data?.detail || '알 수 없는 오류'));
    }
    };

    return (
    <div className="auth-form-container">
        <h2>로그인</h2>
        <form onSubmit={handleSubmit}>
        <label>
            사용자 이름:
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <label>
            비밀번호:
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <button type="submit">로그인</button>
        </form>
        <p>아직 계정이 없으신가요? <a href="/register">회원가입</a></p>
    </div>
    );
    }

export default Login;

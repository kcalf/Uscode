import React, { useState } from 'react';
import axios from 'axios';

function JobRegistrationForm({ onJobRegistered, residentId }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    hourly_wage: 0,
    start_date: '',
    end_date: '',
    number_of_workers: 1,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // 이 API는 주민이 알바를 등록하고, 이 알바는 '승인 대기' 상태로 저장됩니다.
    // 관리자가 승인해야 `job_list` 테이블의 `approved`가 True로 변경됩니다.
    axios.post(`${process.env.REACT_APP_API_URL}/jobs/`, formData)
      .then(response => {
        onJobRegistered(response.data); // 부모 컴포넌트에 새로운 알바 정보 전달
        setFormData({ // 폼 초기화
          title: '',
          description: '',
          location: '',
          hourly_wage: 0,
          start_date: '',
          end_date: '',
          number_of_workers: 1,
        });
      })
      .catch(error => {
        alert('알바 등록 요청 중 오류가 발생했습니다.');
        console.error(error);
      });
  };

  return (
    <form onSubmit={handleSubmit} className="job-registration-form">
      <h3>새로운 단기 알바 등록</h3>
      <label>
        제목:
        <input type="text" name="title" value={formData.title} onChange={handleChange} required />
      </label>
      <label>
        설명:
        <textarea name="description" value={formData.description} onChange={handleChange} required />
      </label>
      <label>
        위치:
        <input type="text" name="location" value={formData.location} onChange={handleChange} required />
      </label>
      <label>
        시급:
        <input type="number" name="hourly_wage" value={formData.hourly_wage} onChange={handleChange} required />
      </label>
      <label>
        시작 날짜:
        <input type="date" name="start_date" value={formData.start_date} onChange={handleChange} required />
      </label>
      <label>
        종료 날짜:
        <input type="date" name="end_date" value={formData.end_date} onChange={handleChange} required />
      </label>
      <label>
        필요 인원:
        <input type="number" name="number_of_workers" value={formData.number_of_workers} onChange={handleChange} min="1" required />
      </label>
      <button type="submit">알바 등록 요청</button>
    </form>
  );
}

export default JobRegistrationForm;

// frontend/src/components/ServiceIntro.js
import React from 'react';
import './ServiceIntro.css';

function ServiceIntro() {
  return (
    <section className="service-intro">
      <h1>워홀 in 의성</h1>
      <p className="subtitle">
        의성군의 미래를 열어갈 청년 워킹 홀리데이 플랫폼<br />
        <strong>일자리 · 숙박 · 지역 체험의 통합 솔루션</strong>
      </p>
      
      <div className="intro-content">
        <div className="mission-statement">
          <h2>의성군의 새로운 도약, 청년과 함께</h2>
          <p>
            인구 소멸 위기에 직면한 의성군에 새로운 활력을 불어넣기 위해 탄생했습니다.<br />
            단순한 알바 중개를 넘어, <strong>청년들이 의성에서 생활하며 지역의 가치를 발견</strong>하고<br />
            <strong>장기 정착으로 이어질 수 있는 선순환 체계</strong>를 구축합니다.
          </p>
        </div>

        <div className="core-features">
          <h2>차별화된 서비스의 핵심</h2>
          <ul>
            <li>
              <strong>통합형 워킹 홀리데이 경험</strong>
              <p>단순 일자리 제공이 아닌 숙박(빈집 활용) + 지역화폐(의성사랑상품권) + 지역 체험을 결합한 종합 패키지</p>
            </li>
            <li>
              <strong>지역 맞춤형 일자리 큐레이션</strong>
              <p>농가 일손 돕기, 지역 축제 스태프, 소상공인 지원 등 의성군의 실제 수요를 반영한 일자리 제공</p>
            </li>
            <li>
              <strong>지역 경제 선순환 구조</strong>
              <p>청년의 소비가 지역 화폐로 직접 환원되어 지역 경제 활성화에 기여하는 혁신 모델</p>
            </li>
            <li>
              <strong>의성 가치 재발견</strong>
              <p>청년들이 직접 발견한 의성의 매력을 SNS 등으로 확산하는 바이럴 마케팅 효과 창출</p>
            </li>
          </ul>
        </div>

        <div className="target-audience">
          <h2>이런 분들에게 추천합니다</h2>
          <div className="audience-grid">
            <div className="audience-card">
              <div className="icon">🌱</div>
              <h3>진로 탐색 청년</h3>
              <p>방학/휴학 중 새로운 경험으로 진로를 탐색하고 싶은 분</p>
            </div>
            <div className="audience-card">
              <div className="icon">✈️</div>
              <h3>글로벌 준비 청년</h3>
              <p>해외 워홀 전 국내에서 적응력 키우고 싶은 분</p>
            </div>
            <div className="audience-card">
              <div className="icon">🔋</div>
              <h3>재충전이 필요한 청년</h3>
              <p>번아웃으로 퇴사 후 새로운 환경에서 재정비하는 분</p>
            </div>
            <div className="audience-card">
              <div className="icon">🏞️</div>
              <h3>지역 삶 체험 청년</h3>
              <p>도시 생활에 지쳐 농촌의 삶을 경험하고 싶은 분</p>
            </div>
          </div>
        </div>

        <div className="tech-stack">
          <h2>기술적 기반</h2>
          <ul>
            <li><strong>Frontend</strong>: React.js, CSS, Axios</li>
            <li><strong>Backend</strong>: FastAPI, SQLAlchemy, PostgreSQL</li>
            <li><strong>Infra</strong>: Docker, Google Cloud Platform, Nginx</li>
            <li><strong>AI Integration</strong>: Gemini API 기반 지역 특화 추천 시스템(탐구 중)</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

export default ServiceIntro;

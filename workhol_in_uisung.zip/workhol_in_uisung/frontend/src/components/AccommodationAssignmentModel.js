import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AccommodationAssignmentModal({ isOpen, onClose, applicantId, jobStartDate, jobEndDate, requiredCapacity }) {
  const [assignedAccommodation, setAssignedAccommodation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen && applicantId) {
      // TODO: 백엔드에서 해당 지원자에게 배정된 숙소가 있는지 확인하는 API 호출 필요
      // 현재는 단순히 숙소 배정을 시도하는 로직으로 구성됨
      // 실제 구현에서는 지원자ID로 숙소 정보를 조회해야 합니다.
    }
  }, [isOpen, applicantId]);

  const handleAssignAccommodation = () => {
    setLoading(true);
    setError(null);
    axios.post(`${process.env.REACT_APP_API_URL}/accommodations/assign`, {
      applicant_id: applicantId,
      job_start_date: jobStartDate, // 숙소 배정 로직에 필요한 정보
      job_end_date: jobEndDate,
      required_capacity: requiredCapacity,
    })
      .then(response => {
        setAssignedAccommodation(response.data);
        setLoading(false);
      })
      .catch(err => {
        setError('숙소 배정 실패: ' + (err.response?.data?.detail || '알 수 없는 오류'));
        setLoading(false);
      });
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>숙소 배정 결과</h2>
        {loading && <p>숙소를 찾고 있습니다...</p>}
        {error && <p className="error">{error}</p>}
        {assignedAccommodation ? (
          <div>
            <p>축하합니다! 숙소가 배정되었습니다:</p>
            <p>주소: {assignedAccommodation.address}</p>
            <p>수용 인원: {assignedAccommodation.capacity}</p>
          </div>
        ) : (
          <p>아직 숙소가 배정되지 않았습니다. 승인 후 숙소가 자동으로 배정됩니다.</p>
        )}
        <button onClick={onClose}>닫기</button>
        {/* 관리자나 주민이 수동으로 숙소 배정을 트리거하는 버튼 (옵션) */}
        {!assignedAccommodation && !loading && (
          <button onClick={handleAssignAccommodation}>숙소 배정 시도</button>
        )}
      </div>
    </div>
  );
}

export default AccommodationAssignmentModal;

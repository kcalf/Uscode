import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

function JobList() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/users/`)
      .then(response => {
        setJobs(response.data);
      })
      .catch(error => {
        console.error('Error fetching jobs:', error);
      });
  }, []);

  return (
    <div>
      <h1>단기 알바 리스트</h1>
      <ul>
        {jobs.map(job => (
          <li key={job.id}>
            <Link to={`/apply/${job.id}`}>{job.title} - {job.location}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default JobList;

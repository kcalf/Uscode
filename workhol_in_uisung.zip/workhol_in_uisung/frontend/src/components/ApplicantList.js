import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ApplicantList({ jobId }) {
  const [applicants, setApplicants] = useState([]);

  useEffect(() => {
    fetchApplicants();
  }, [jobId]);

  const fetchApplicants = () => {
    axios.get(`${process.env.REACT_APP_API_URL}/applicants/job/${jobId}`)
      .then(response => {
        setApplicants(response.data);
      })
      .catch(error => {
        console.error('Error fetching applicants:', error);
      });
  };

  const handleApproveApplicant = (applicantId) => {
    // TODO: 지원자 승인/거절 API (백엔드 `crud.py` 및 `applicants` 라우터에 추가 필요)
    // 이 API는 `applicants` 테이블의 `approved` 필드를 True로 변경하고,
    // 숙소 배정 로직을 트리거하며 사용자에게 알림을 보냅니다.
    console.log(`지원자 ${applicantId} 승인 요청 (알바 ID: ${jobId})`);
    alert('지원자 승인 기능은 백엔드 구현이 필요합니다.');
    // axios.post(`${process.env.REACT_APP_API_URL}/applicants/${applicantId}/approve`)
    //   .then(() => fetchApplicants())
    //   .catch(error => console.error(error));
  };

  const handleRejectApplicant = (applicantId) => {
    // TODO: 지원자 거절 API (백엔드 `crud.py` 및 `applicants` 라우터에 추가 필요)
    console.log(`지원자 ${applicantId} 거절 요청 (알바 ID: ${jobId})`);
    alert('지원자 거절 기능은 백엔드 구현이 필요합니다.');
    // axios.post(`${process.env.REACT_APP_API_URL}/applicants/${applicantId}/reject`)
    //   .then(() => fetchApplicants())
    //   .catch(error => console.error(error));
  };

  return (
    <div className="applicant-list">
      <h4>지원자 목록</h4>
      {applicants.length === 0 ? (
        <p>아직 지원자가 없습니다.</p>
      ) : (
        <ul>
          {applicants.map(applicant => (
            <li key={applicant.id}>
              {applicant.user_name} ({applicant.contact}) - 상태: {applicant.approved ? '승인됨' : '대기중'}
              {!applicant.approved && (
                <>
                  <button onClick={() => handleApproveApplicant(applicant.id)}>승인</button>
                  <button onClick={() => handleRejectApplicant(applicant.id)}>거절</button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ApplicantList;

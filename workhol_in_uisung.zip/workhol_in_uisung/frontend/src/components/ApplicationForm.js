// frontend/src/components/ApplicationForm.js
import React, { useState, useEffect } from 'react';
import { generateGeminiSentence } from '../services/gemini';

const ApplicationForm = ({ job, onClose, onApply }) => {
  const [formData, setFormData] = useState({ 
    name: '', 
    birthDate: '', 
    contact: '', 
    otherInfo: '' 
  });
  const [geminiText, setGeminiText] = useState('');

  useEffect(() => {
    const fetchGemini = async () => {
      const text = await generateGeminiSentence(job.title, job.description);
      setGeminiText(text || '');
    };
    fetchGemini();
  }, [job]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onApply(job.id, formData);
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div style={{ display: 'flex', gap: '2em', justifyContent: 'center', alignItems: 'flex-start' }}>
        <div className="modal-content" style={{ minWidth: 350 }}>
          <h3>{job.title} 지원하기</h3>
          <form onSubmit={handleSubmit}>
            <label>
              이름: 
              <input type="text" name="name" onChange={handleChange} required />
            </label>
            <label>
              생년월일: 
              <input type="date" name="birthDate" onChange={handleChange} required />
            </label>
            <label>
              연락처: 
              <input type="tel" name="contact" onChange={handleChange} required />
            </label>
            <label>
              기타 (선택): 
              <textarea name="otherInfo" onChange={handleChange}></textarea>
            </label>
            <div className="form-buttons">
              <button type="submit">제출</button>
              <button type="button" onClick={onClose}>취소</button>
            </div>
          </form>
        </div>
        <div className="gemini-side-panel" style={{ minWidth: 300, maxWidth: 400, background: '#f5f5f5', padding: '1em', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
          <h4 style={{ marginTop: 0 }}>Gemini 추천 문장</h4>
          <p>의성군에서 함께할 마늘 수확 알바를 모집합니다! 드넓은 밭에서 신선한 마늘을 직접 수확하며 자연과 하나 되는 경험을 해보세요. 육체적으로 조금 힘들 수 있지만, 그만큼 보람과 성취감을 느낄 수 있는 귀한 시간이 될 거예요.</p>
            <div>{geminiText}</div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationForm;
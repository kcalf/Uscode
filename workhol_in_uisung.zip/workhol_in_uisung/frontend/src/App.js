// frontend/src/App.js
import React from 'react';
import { Routes, Route, Link, Navigate } from 'react-router-dom';
import HomePage from './pages/HomePage';
import Login from './components/Login';
import Register from './components/Register';
import ResidentDashboard from './pages/ResidentDashboard';
import AdminDashboard from './pages/AdminDashboard';
import { useAuth } from './contexts/AuthContext';
import JobListPage from './pages/JobListPage';

// 역할별 접근 제어용 보호 라우트 컴포넌트
const ProtectedRoute = ({ children, allowedRoles }) => {
    const { user, loading } = useAuth();

    if (loading) {
    return <div>Loading...</div>;
    }

    if (!user) {
    // 로그인 안 된 경우 로그인 페이지로 이동
    return <Navigate to="/login" replace />;
    }

    if (allowedRoles && !allowedRoles.includes(user.role)) {
    // 권한이 없으면 홈으로 리다이렉트
    return <Navigate to="/" replace />;
    }

    return children;
    };

    function App() {
    const { user, signOut } = useAuth();

    return (
    <div className="App">
        <nav style={{ padding: '10px', borderBottom: '1px solid #ccc' }}>
        <Link to="/" style={{ marginRight: '15px' }}>홈</Link>
        <Link to="/jobs" style={{ marginRight: '15px' }}>알바 목록</Link> {}
        {user ? (
            <>
            {/* 역할별 메뉴 노출 */}
            {user.role === 'resident' && <Link to="/resident" style={{ marginRight: '15px' }}>주민 대시보드</Link>}
            {user.role === 'admin' && <Link to="/admin" style={{ marginRight: '15px' }}>관리자 대시보드</Link>}

            <span style={{ marginRight: '15px' }}>
                환영합니다, {user.username} ({user.role})
            </span>
            <button onClick={signOut}>로그아웃</button>
            </>
        ) : (
            <>
            <Link to="/login" style={{ marginRight: '15px' }}>로그인</Link>
            <Link to="/register">회원가입</Link>
            </>
        )}
        </nav>

        <div style={{ padding: '20px' }}>
        <Routes>
            {/* 누구나 접근 가능한 홈 */}
            <Route path="/" element={<HomePage />} />

            {/* 인증 필요 없는 로그인/회원가입 */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* 주민 대시보드: 주민 권한만 접근 가능 */}
            <Route
            path="/resident"
            element={
                <ProtectedRoute allowedRoles={['resident']}>
                <ResidentDashboard />
                </ProtectedRoute>
            }
            />

            {/* 관리자 대시보드: 관리자 권한만 접근 가능 */}
            <Route
            path="/admin"
            element={
                <ProtectedRoute allowedRoles={['admin']}>
                <AdminDashboard />
                </ProtectedRoute>
            }
            />

            {/* 알바 목록: 누구나 접근 가능 */}
            <Route path="/jobs" element={<JobListPage />} />

            {/* 그 외 경로는 홈으로 리다이렉트 */}
            <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        </div>
    </div>
    );
}

export default App;

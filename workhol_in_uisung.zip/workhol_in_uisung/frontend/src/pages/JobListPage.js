// frontend/src/pages/JobListPage.js
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import ApplicationForm from '../components/ApplicationForm'; // 지원하기 폼 컴포넌트 분리
import { getJobs } from '../services/api';

function JobListPage() {
  const [jobs, setJobs] = useState([]);
  const [filters, setFilters] = useState({ startDate: '', endDate: '', workers: 1 });
  const [selectedJob, setSelectedJob] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await getJobs();
        setJobs(response.data);
        setIsLoading(false);
      } catch (err) {
        setError("알바 목록을 불러오는 데 실패했습니다.");
        setIsLoading(false);
      }
    };
    fetchJobs();
  }, [filters]);

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleApply = async (jobId, applicationData) => {
    // TODO: 지원 API 호출
    console.log("Applying for job:", jobId, applicationData);
    alert(`${jobId}번 알바에 지원이 완료되었습니다.`);
    alert(`의성읍 도동리 80-1번지 숙소 307호에 배정되었습니다.`);
  };

  if (isLoading) return <div>로딩 중...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="job-list-page">
      <h1>모집 중인 단기 알바</h1>
      
      <div className="filter-container">
        <label>시작 날짜: <input type="date" name="startDate" onChange={handleFilterChange} /></label>
        <label>종료 날짜: <input type="date" name="endDate" onChange={handleFilterChange} /></label>
        <label>필요 인원: <input type="number" name="workers" min="1" defaultValue="1" onChange={handleFilterChange} /></label>
      </div>

      <ul className="job-list">
        {jobs.map(job => (
          <li key={job.id} className="job-item">
            <h3>{job.title}</h3>
            <p>위치: {job.location} | 시급: {job.hourly_wage?.toLocaleString()}원</p>
            <p>모집인원: {job.number_of_workers}명 | 기간: {job.start_date} ~ {job.end_date}</p>
            {user?.role === 'user' && (
              <button onClick={() => setSelectedJob(job)}>지원하기</button>
            )}
          </li>
        ))}
      </ul>

      {selectedJob && (
        <ApplicationForm 
          job={selectedJob} 
          onClose={() => setSelectedJob(null)} 
          onApply={handleApply} 
        />
      )}
    </div>
  );
}

export default JobListPage;

// frontend/src/pages/HomePage.js
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getJobs, createApplicant } from '../services/api'; 
import ServiceIntro from '../components/ServiceIntro';

const ApplicationForm = ({ job, onClose, onApply }) => {
  const [formData, setFormData] = useState({ user_name: '', birth_date: '', contact: '', other_info: '' });
  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await onApply(job.id, formData);
      alert('성공적으로 지원했습니다.');
      onClose();
    } catch (error) {
      alert('지원 중 오류가 발생했습니다: ' + (error.response?.data?.detail || error.message));
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>{job.title} 지원하기</h3>
        <form onSubmit={handleSubmit}>
          <label>이름: <input type="text" name="user_name" onChange={handleChange} required /></label>
          <label>생년월일: <input type="date" name="birth_date" onChange={handleChange} required /></label>
          <label>연락처: <input type="text" name="contact" onChange={handleChange} required /></label>
          <label>기타 (선택): <textarea name="other_info" onChange={handleChange}></textarea></label>
          <button type="submit">제출</button>
          <button type="button" onClick={onClose}>취소</button>
        </form>
      </div>
    </div>
  );
};

function HomePage() {
  const [jobs, setJobs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);
  const { user } = useAuth();

  const fetchJobs = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getJobs();
      setJobs(response.data);
    } catch (err) {
      setError("알바 목록을 불러오는 데 실패했습니다.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleApply = async (jobId, applicationData) => {
    const dataToSubmit = { ...applicationData, job_id: jobId };
    await createApplicant(dataToSubmit); // createApplicant는 백엔드의 POST /users/apply를 호출
    fetchJobs(); // 지원 후 목록을 새로고침하여 변경사항(예: 모집 마감)을 반영
  };

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="home-page">
      <ServiceIntro />
      <div className="call-to-action">
        <h2>의성에서 새로운 경험을 시작해보세요!</h2>
        <p>
          지금 바로 <a href="/jobs">모집 중인 알바</a>를 확인하고 지원하세요.<br />
          의성군의 특별한 워킹홀리데이를 경험할 수 있습니다.
        </p>
      </div>
    </div>
  );
}

export default HomePage;
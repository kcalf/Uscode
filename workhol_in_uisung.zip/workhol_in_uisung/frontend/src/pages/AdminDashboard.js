// frontend/src/pages/AdminDashboard.js
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
    getAdminApprovalRequests,
    approveJobRequestByAdmin,
    rejectJobRequestByAdmin
} from '../services/api';

function AdminDashboard() {
  const [approvalRequests, setApprovalRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user, token } = useAuth();

  const fetchRequests = useCallback(async () => {
    if (user && user.role === 'admin' && token) {
      setIsLoading(true);
      setError(null);
      try {
        const response = await getAdminApprovalRequests(token);
        setApprovalRequests(response.data);
      } catch (err) {
        setError("승인 요청 목록을 불러오는 데 실패했습니다.");
      } finally {
        setIsLoading(false);
      }
    }
  }, [user, token]);

  useEffect(() => {
    fetchRequests();
  }, [fetchRequests]);

  const handleApprovalAction = async (requestId, action) => {
    if (!window.confirm(`정말로 이 요청을 ${action === 'approve' ? '승인' : '거절'}하시겠습니까?`)) return;
    try {
      if (action === 'approve') {
        await approveJobRequestByAdmin(requestId, token);
        alert("요청이 성공적으로 승인되었습니다.");
      } else {
        await rejectJobRequestByAdmin(requestId, token);
        alert("요청이 성공적으로 거절되었습니다.");
      }
      setApprovalRequests(prev => prev.filter(req => req.id !== requestId));
    } catch (err) {
      alert("처리 중 오류가 발생했습니다.");
    }
  };

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="admin-dashboard">
      <h1>관리자 대시보드</h1>
      <div className="dashboard-card">
        <h3>단기 알바 리스트 추가 승인 요청</h3>
        {approvalRequests.length > 0 ? (
          <ul>
            {approvalRequests.map(req => (
              <li key={req.id}>
                <span><strong>{req.job?.title || '알 수 없는 제목'}</strong> (요청 ID: {req.id})</span>
                <div>
                  <button onClick={() => handleApprovalAction(req.id, 'approve')}>승인</button>
                  <button onClick={() => handleApprovalAction(req.id, 'reject')}>거절</button>
                </div>
              </li>
            ))}
          </ul>
        ) : <p>새로운 승인 요청이 없습니다.</p>}
      </div>
      {/* 관리자 직접 추가 폼은 생략 (기존과 동일) */}
    </div>
  );
}
export default AdminDashboard;

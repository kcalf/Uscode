from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import os

# OAuth 2.0 클라이언트 설정 파일 경로
CLIENT_SECRETS_FILE = 'C:/Users/as4761285 470/Downloads/credentials.json'
SCOPES = ['https://www.googleapis.com/auth/drive.file']

# 인증 및 API 클라이언트 생성
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)
creds = flow.run_local_server(port=0)
drive_service = build('drive', 'v3', credentials=creds)

# 파일 업로드 예시
file_metadata = {'name': 'example.txt'}
with open('example.txt', 'w') as f:
    f.write('This is a test file uploaded using Google Drive API.')

media = MediaFileUpload('example.txt', mimetype='text/plain')
file = drive_service.files().create(body=file_metadata, media_body=media, fields='id').execute()
print(f'File ID: {file.get("id")}')

import google.generativeai as genai

# Gemini API 키 (여기서는 예시로 사용. 실제로는 별도 발급받은 키를 입력)
api_key = "AIzaSyA9fq3PDXkNt_LxL9X-PclHFC1a9niv_L0"  # <-- 직접 입력 필요
genai.configure(api_key=api_key)

model = genai.GenerativeModel('gemini-1.5-flash')

# 키워드 기반 문장 생성
try:
    response = model.generate_content(
        "키워드: 마늘농사, 작물수확하기 → 자연스러운 알바 구인 문장 생성",
        generation_config={"max_output_tokens": 70}
    )
    print(response.text)
except Exception as e:  # google.generativeai.APIError가 아니라 일반 Exception으로 처리
    print(f"Gemini API 오류: {e}")
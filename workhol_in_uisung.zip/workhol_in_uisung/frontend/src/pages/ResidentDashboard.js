// frontend/src/pages/ResidentDashboard.js
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom'
import {
    getResidentJobs,
    approveApplicantByResident,
    rejectApplicantByResident,
    getResidentLastProfile,
    createJobRequest,
    getJobs
} from '../services/api';
import { generateGeminiSentence } from '../services/gemini';

// '내 알바 목록'을 별도의 컴포넌트로 분리하여 상태 관리를 독립시킨다.
const MyJobList = () => {
    const [myJobs, setMyJobs] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const { user, token } = useAuth();
    const navigate = useNavigate();

    const fetchMyJobs = useCallback(async () => {
        if (user && token) {
            setIsLoading(true);
            setError(null);
            try {
                const response = await getResidentJobs(token);
                setMyJobs(response.data);
            } catch (err) {
                setError("내 알바 목록을 불러오는 데 실패했습니다.");
                console.error("Failed to fetch resident's jobs:", err);
            } finally {
                setIsLoading(false);
            }
        }
    }, [user, token]);

    useEffect(() => {
        fetchMyJobs();
    }, [fetchMyJobs]);

    const handleApplicantAction = async (applicantId, action) => {
        // ... (기존 지원자 처리 로직은 그대로)
        try {
            if (action === 'approve') {
                await approveApplicantByResident(applicantId, token);
                alert("지원자를 승인했습니다. 해당 알바는 모집 마감 처리됩니다.");

                navigate('/'); 
            } else {
                await rejectApplicantByResident(applicantId, token);
                alert("지원자를 거절했습니다.");
                fetchMyJobs(); // 거절 시에는 현재 페이지만 새로고침
            }
        } catch (err) {
            alert("처리 중 오류가 발생했습니다.");
        }
    };

    if (isLoading) return <div>내 알바 목록을 불러오는 중...</div>;
    if (error) return <div style={{ color: 'red', marginTop: '1rem' }}>{error}</div>;

    return (
        <div className="dashboard-card">
            <h3>내 알바 지원자 관리</h3>
            {myJobs.length > 0 ? myJobs.map(job => (
                <div key={job.id} className="my-job-item">
                    <h4>{job.title} (모집 상태: {job.approved ? '모집중' : '마감'})</h4>{}
                    {job.applicants && job.applicants.length > 0 ? (
                        <ul className="applicant-list">
                            {job.applicants.map(applicant => (
                                <li key={applicant.id}>
                                    <span>{applicant.user_name} ({applicant.approved ? '승인됨' : '대기중'})</span>
                                    {!applicant.approved && job.approved && (
                                        <div>
                                            <button onClick={() => handleApplicantAction(applicant.id, 'approve')}>승인</button>
                                            <button onClick={() => handleApplicantAction(applicant.id, 'reject')}>거절</button>
                                        </div>
                                    )}
                                </li>
                            ))}
                        </ul>
                    ) : <p>아직 지원자가 없습니다.</p>}
                </div>
            )) : <p>등록한 알바가 없습니다.</p>}
        </div>
    );
};

// '알바 등록 폼'을 별도의 컴포넌트로 분리한다.
const JobRegistrationForm = ({ jobTitle, setJobTitle, jobDesc, setJobDesc }) => {
    const [profile, setProfile] = useState({
        title: '', description: '', location: '', hourly_wage: '',
        start_date: '', end_date: '', number_of_workers: 1
    });
    const { token } = useAuth();

    useEffect(() => {
        setProfile(prev => ({ ...prev, title: jobTitle, description: jobDesc }));
    }, [jobTitle, jobDesc]);

    const handleProfileChange = (e) => {
        setProfile({ ...profile, [e.target.name]: e.target.value });
        if (e.target.name === 'title') setJobTitle(e.target.value);
        if (e.target.name === 'description') setJobDesc(e.target.value);
    };

    const handleLoadProfile = async () => {
        try {
            const response = await getResidentLastProfile(token);
            const lastJob = response.data;
            setProfile({
                title: lastJob.title,
                description: lastJob.description,
                location: lastJob.location,
                hourly_wage: lastJob.hourly_wage,
                start_date: lastJob.start_date,
                end_date: lastJob.end_date,
                number_of_workers: lastJob.number_of_workers
            });
            alert("이전에 작성한 프로필을 불러왔습니다.");
        } catch (error) {
            if (error.response?.status === 404) {
                alert("이전에 작성한 프로필이 없습니다.");
            } else {
                alert("프로필을 불러오는 중 오류가 발생했습니다.");
            }
        }
    };

    const handleJobSubmit = async (e) => {
        e.preventDefault();
        try {
            await createJobRequest(profile, token);
            alert("알바 등록 요청이 완료되었습니다.");
            setProfile({ title: '', description: '', location: '', hourly_wage: '', start_date: '', end_date: '', number_of_workers: 1 });
        } catch (err) {
            alert("알바 등록 요청 중 오류가 발생했습니다.");
        }
    };

    return (
        <div className="dashboard-card">
            <h3>내 프로필 및 알바 등록</h3>
            <button onClick={handleLoadProfile} style={{ float: 'right' }}>이전 프로필 불러오기</button>
            <form onSubmit={handleJobSubmit}>
                <label>알바 제목: <input type="text" name="title" value={profile.title} onChange={handleProfileChange} required /></label>
                <label>업무 내용: <textarea name="description" value={profile.description} onChange={handleProfileChange} required></textarea></label>
                <label>도로명 주소: <input type="text" name="location" value={profile.location} onChange={handleProfileChange} required /></label>
                <label>시급: <input type="number" name="hourly_wage" value={profile.hourly_wage} onChange={handleProfileChange} required /></label>
                <label>시작 날짜: <input type="date" name="start_date" value={profile.start_date} onChange={handleProfileChange} required /></label>
                <label>종료 날짜: <input type="date" name="end_date" value={profile.end_date} onChange={handleProfileChange} required /></label>
                <label>필요 인원: <input type="number" name="number_of_workers" value={profile.number_of_workers} min="1" onChange={handleProfileChange} required /></label>
                <button type="submit">알바 등록 요청</button>
            </form>
        </div>
    );
};

// JobList를 Gemini용으로 재정의 (팝업용)
const JobListForGemini = ({ onJobClick }) => {
    const [jobs, setJobs] = useState([]);
    useEffect(() => {
        // 기존 getJobs API 사용
        import('../services/api').then(({ getJobs }) => {
            getJobs().then(res => setJobs(res.data)).catch(() => setJobs([]));
        });
    }, []);
    return (
        <div className="dashboard-card">
            <h3>알바 리스트 (Gemini 문장 생성)</h3>
            <ul>
                {jobs.map(job => (
                    <li key={job.id}>
                        <button style={{ background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}
                            onClick={() => onJobClick(job.title, job.description)}>
                            {job.title} - {job.location}
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

// 메인 ResidentDashboard 컴포넌트는 두 하위 컴포넌트를 렌더링하기만 한다.
function ResidentDashboard() {
    // 알바 등록 폼의 제목/내용 상태를 상위에서 관리
    const [jobTitle, setJobTitle] = useState('');
    const [jobDesc, setJobDesc] = useState('');
    const [geminiText, setGeminiText] = useState('');
    const [showPopup, setShowPopup] = useState(false);

    // 팝업 닫기
    const handleClosePopup = () => setShowPopup(false);

    // JobList에서 알바 클릭 시 Gemini 문장 생성
    const handleJobClick = async (title, description) => {
        const text = await generateGeminiSentence(title, description);
        if (text) {
            setGeminiText(text);
            setShowPopup(true);
        }
    };

    return (
        <div className="resident-dashboard">
            <h1>주민 대시보드</h1>
            <JobRegistrationForm
                jobTitle={jobTitle}
                setJobTitle={setJobTitle}
                jobDesc={jobDesc}
                setJobDesc={setJobDesc}
            />
            <MyJobList />
            <JobListForGemini onJobClick={handleJobClick} />
            {showPopup && (
                <div className="gemini-popup" style={{ position: 'fixed', top: '30%', left: '50%', transform: 'translate(-50%, -50%)', background: '#fff', border: '1px solid #888', padding: 24, zIndex: 1000 }}>
                    <div style={{ marginBottom: 16 }}>{geminiText}</div>
                    <button onClick={handleClosePopup}>닫기</button>
                </div>
            )}
        </div>
    );
}

export default ResidentDashboard;

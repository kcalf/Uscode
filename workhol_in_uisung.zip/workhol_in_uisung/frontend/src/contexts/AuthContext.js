// frontend/src/contexts/AuthContext.js
import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { login, register, getMe } from '../services/auth';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // { id, username, role, ... }
  const [token, setToken] = useState(localStorage.getItem('access_token'));
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const loadUser = useCallback(async (accessToken) => {
    if (!accessToken) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const userData = await getMe(accessToken);
      setUser(userData);
      localStorage.setItem('access_token', accessToken);
    } catch (error) {
      console.error('Failed to load user:', error);
      setUser(null);
      localStorage.removeItem('access_token');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUser(token);
  }, [token, loadUser]);

  const signIn = async (username, password) => {
    setLoading(true);
    try {
      const data = await login(username, password);
      setToken(data.access_token);
      setUser(data.user);
      localStorage.setItem('access_token', data.access_token);
      return true;
    } catch (error) {
      console.error('Login failed:', error);
      setLoading(false);
      throw error;
    }
  };

  const signUp = async (username, password, role, email) => {
    setLoading(true);
    try {
      const data = await register(username, password, role, email);
      // 회원가입 후 자동 로그인 (선택 사항)
      await signIn(username, password);
      return data;
    } catch (error) {
      console.error('Registration failed:', error);
      setLoading(false);
      throw error;
    }
  };

  const signOut = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('access_token');
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
